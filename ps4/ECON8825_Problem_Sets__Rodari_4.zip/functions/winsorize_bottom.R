winsorize = function(x, cut = 0.05){
  
  x
  cut_point_top <- quantile(x, 1 - cut, na.rm = T)
  cut_point_bottom <- quantile(x, cut, na.rm = T)
  
  j = which(x <= cut_point_bottom) 
  x[j] = cut_point_bottom
  
  
  return(x)
}
